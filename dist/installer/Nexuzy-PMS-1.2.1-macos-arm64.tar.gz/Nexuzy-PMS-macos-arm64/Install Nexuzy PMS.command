#!/bin/bash
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Applications"
mkdir -p "$DEST"
rm -rf "$DEST/Nexuzy PMS.app"
cp -R "$HERE/Nexuzy PMS.app" "$DEST/"
xattr -dr com.apple.quarantine "$DEST/Nexuzy PMS.app" 2>/dev/null || true
mkdir -p "$HOME/Desktop"
ln -sfn "$DEST/Nexuzy PMS.app" "$HOME/Desktop/Nexuzy PMS.app" 2>/dev/null || true
open "$DEST/Nexuzy PMS.app"
