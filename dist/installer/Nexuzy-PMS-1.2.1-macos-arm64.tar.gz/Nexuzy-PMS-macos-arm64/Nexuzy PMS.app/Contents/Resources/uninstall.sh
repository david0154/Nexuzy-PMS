#!/bin/bash
set -e
APP="$(cd "$(dirname "$0")/../.." && pwd)"
rm -f "$HOME/Desktop/Nexuzy PMS.app"
rm -rf "$APP"
if [ "$1" = "--purge" ]; then
  rm -rf "$HOME/Library/Application Support/Nexuzy PMS"
  echo "Nexuzy PMS removed, including hotel data."
else
  echo "Nexuzy PMS removed. Hotel data is preserved in $HOME/Library/Application Support/Nexuzy PMS"
  echo "To erase it later: rm -rf "$HOME/Library/Application Support/Nexuzy PMS""
fi
