Nexuzy PMS 1.2.1 for macOS x64

This package already contains Node.js and SQLite; no Node.js install is needed.

1. Double-click "Install Nexuzy PMS.command".
2. If macOS blocks it, right-click it and choose Open.
3. The app is copied to ~/Applications and a Desktop shortcut is created.

Hotel data is stored in ~/Library/Application Support/Nexuzy PMS and
is preserved across upgrades and uninstall.

To uninstall, use Settings > About, Support & Uninstall inside the app.

The app is not code-signed or notarized. Gatekeeper may warn on first
launch; right-click the app and choose Open.
