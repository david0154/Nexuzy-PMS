#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
TARGET="${NEXUZY_INSTALL_DIR:-$HOME/.local/share/nexuzy-pms}"
if [ "$HERE" = "$TARGET" ]; then
  echo "Run install.sh from the extracted Nexuzy PMS package."
  exit 1
fi
mkdir -p "$TARGET"
cp -a "$HERE"/. "$TARGET"/
chmod +x "$TARGET/node/bin/node" "$TARGET/launch.sh" "$TARGET/install.sh" "$TARGET/uninstall.sh"
APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"
DESKTOP="$APPS/nexuzy-pms.desktop"
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Nexuzy PMS
Comment=Hotel, Restaurant and Property Management
Exec="$TARGET/launch.sh"
Path=$TARGET
Icon=$TARGET/nexuzy.png
Terminal=false
StartupNotify=true
Categories=Office;Finance;
EOF
chmod +x "$DESKTOP"
if [ -d "$HOME/Desktop" ]; then
  cp "$DESKTOP" "$HOME/Desktop/nexuzy-pms.desktop"
  chmod +x "$HOME/Desktop/nexuzy-pms.desktop"
fi
echo "Nexuzy PMS installed to $TARGET"
echo "Launch it from the application menu, the desktop shortcut, or $TARGET/launch.sh"
if [ "$1" != "--no-launch" ]; then
  (nohup "$TARGET/launch.sh" >/dev/null 2>&1 &)
fi
