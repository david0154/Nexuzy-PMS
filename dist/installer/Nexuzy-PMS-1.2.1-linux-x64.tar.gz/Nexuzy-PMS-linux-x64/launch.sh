#!/bin/sh
cd "$(dirname "$0")" || exit 1
exec ./node/bin/node scripts/launch.js
