Nexuzy PMS 1.2.1 for Linux x64

This package already contains Node.js and SQLite; no Node.js install is needed.

Easy install:
  1. chmod +x Nexuzy-PMS-1.2.1-linux-x64.run
  2. ./Nexuzy-PMS-1.2.1-linux-x64.run

Or from the tar.gz:
  tar -xzf Nexuzy-PMS-1.2.1-linux-x64.tar.gz
  cd Nexuzy-PMS-linux-x64
  ./install.sh

Installs to ~/.local/share/nexuzy-pms and creates an application-menu
entry plus a desktop shortcut. Use NEXUZY_INSTALL_DIR to choose another
folder. Hotel data stays in the install folder and is preserved on upgrade.

To uninstall, use Settings > About, Support & Uninstall inside the app.
Hotel data is retained in the install folder. You can also run
  ~/.local/share/nexuzy-pms/uninstall.sh

The app window uses Chrome, Chromium, Edge or Brave when available;
otherwise Nexuzy PMS opens in the default browser.
