#!/bin/sh
set -e
PURGE=0
if [ "$1" = "--purge" ]; then PURGE=1; shift; fi
TARGET=$(cd "$(dirname "$0")" && pwd)
if [ "$1" != "--run" ]; then
  TMP="${TMPDIR:-/tmp}/nexuzy-uninstall-$$.sh"
  cp "$0" "$TMP"
  chmod +x "$TMP"
  exec sh "$TMP" --run "$TARGET" "$PURGE"
fi
TARGET="$2"
PURGE="${3:-0}"
rm -f "$HOME/.local/share/applications/nexuzy-pms.desktop"
rm -f "$HOME/Desktop/nexuzy-pms.desktop"
if [ "$PURGE" = "1" ]; then
  cd "$HOME"
  rm -rf "$TARGET"
  echo "Nexuzy PMS removed, including hotel data."
elif [ -d "$TARGET/data" ]; then
  find "$TARGET" -mindepth 1 -maxdepth 1 ! -name data -exec rm -rf {} +
  echo "Nexuzy PMS removed. Hotel data is preserved in $TARGET/data"
  echo "To erase it later: rm -rf "$TARGET/data""
else
  cd "$HOME"
  rm -rf "$TARGET"
  echo "Nexuzy PMS removed."
fi
